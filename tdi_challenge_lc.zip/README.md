# TDI
TDI Hypothesis Testing and Bayesian Inference
